# Phase 1 – build modernisation (Gradle 8.9 / AGP 8.5.2 / JDK 17 / NDK r26 / compileSdk 35)

Done: AndroidX migration, `compile`->`implementation/api`, namespaces, Flurry tracking removed,
`once` replaced by local class, jcenter removed, NDK STL gnustl->c++_static, armeabi dropped.

Known open issues (expected on first build):
- Java compile errors against android-35 API surface (fix one by one).
- Native: Substrate hook layer only supports ARM32/x86 -> no arm64 yet (see gradle.properties `vaAbis`).
- targetSdk 28 so Android 15 will install it; runtime hooks still written for Android 8.
- Tencent jars in app/libs are 2017 builds (location picker / map); candidates for removal.
Build: `gradle.bat --no-daemon assembleDebug` (needs NDK 26.1.10909125: sdkmanager "ndk;26.1.10909125")
