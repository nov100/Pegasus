# Phase 1 – build modernisation (Gradle 8.9 / AGP 8.5.2 / JDK 17 / NDK r26 / compileSdk 35)

Done: AndroidX migration, `compile`->`implementation/api`, namespaces, Flurry tracking removed,
`once` replaced by local class, jcenter removed, NDK STL gnustl->c++_static, armeabi dropped.

Known open issues (expected on first build):
- Java compile errors against android-35 API surface (fix one by one).
- Native: Substrate hook layer only supports ARM32/x86 -> no arm64 yet (see gradle.properties `vaAbis`).
- targetSdk 28 so Android 15 will install it; runtime hooks still written for Android 8.
- Tencent jars in app/libs are 2017 builds (location picker / map); candidates for removal.
Build: `gradle.bat --no-daemon assembleDebug` (needs NDK 26.1.10909125: sdkmanager "ndk;26.1.10909125")

## Phase 2 (Android 9-15 runtime fixes, UNTESTED - no SDK build was possible)
- App: HiddenApiBypass exemptions before VirtualCore.startup (all processes).
- HCallbackStub: LAUNCH_ACTIVITY is gone on Android 9+; handle EXECUTE_TRANSACTION / LaunchActivityItem instead.
- InvocationStubManager: every hook is created/injected inside try/catch (log tag "VA++") so one broken hook can't kill the process.
- New ActivityTaskManagerStub (Android 10+): startActivity & co. are served by IActivityTaskManager.
- ActivityStack / ActivityManagerCompat: start/finish stub activity through IActivityTaskManager on Android 10+.
- StartActivity proxy: callingPackage is args[1]; Android 11+ callingFeatureId handled.
- Home: after adding an app, fall back to reloading the list on any failure; drag crash noise removed.

## Phase 2d (fix native SIGSEGV on app launch, from VA Log round 3 on real device)
- Symptom: `io.virtualapp:p0` crashed every time with SIGSEGV (fault addr ~0x9) inside
  `measureNativeOffset` -> `hookAndroidVM`, called from `NativeEngine.launchEngine` during
  `VClientImpl.bindApplicationNoCheck`. This happened on real Android 15 hardware (OPPO
  CPH2505), after the EXECUTE_TRANSACTION fix from phase2c had already fired correctly
  (confirmed: HCallbackStub.handleExecuteTransaction/handleMessage were in the crash stack,
  i.e. the Java-side activity-launch hook worked; the process just died one step later, in
  the native layer).
- Root cause: `measureNativeOffset` looks up `NativeEngine.nativeMark`'s jmethodID and scans
  raw memory near it for a pointer value, assuming an old Dalvik/early-ART `ArtMethod` layout.
  On this device/ART version that lookup can come back null (or the scan can fail to find the
  pointer), and the code did not check for that: it dereferenced memory at/near address 0,
  crashing the whole process (not just skipping the one native patch).
- Fix (`VMPatch.cpp`):
  - `measureNativeOffset`: if the `nativeMark` method id is null, log and return instead of
    dereferencing it.
  - Track whether the offset scan actually found a match (`patchEnv.native_offset_found`).
  - `hookAndroidVM`: if the scan did not find a match, skip installing the four hooks that
    depend on it (`getCallingUid` spoof, dex-open hook, camera setup hook, audio-record
    permission hook) instead of hooking through a bogus offset and crashing later.
- Net effect: on runtimes where this old offset-scanning trick no longer works (seen on
  Android 15), VirtualApp now loses those four specific native patches but the virtual
  process no longer SIGSEGVs, so activity launch should be able to proceed to the next stage.
  NOT YET TESTED ON DEVICE — only compiled by eye / reviewed; this sandbox has no NDK/CMake
  toolchain to actually build the .so, so this must be confirmed via GitHub Actions + VA Log.
- Still open: `VA++ cannot find function: __dl__Z9do_dlopenPKciPK17android_dlextinfoPv` in
  `IOUniformer.cpp::hook_dlopen` — this is already handled safely (symbol lookup failure is
  checked and the hook is just skipped, no crash), so it's logged as a lost feature
  (IO-redirection via dlopen hooking on the linker), not a bug to fix right now.
