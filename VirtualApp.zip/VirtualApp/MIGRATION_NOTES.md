# Phase 1 – build modernisation (Gradle 8.9 / AGP 8.5.2 / JDK 17 / NDK r26 / compileSdk 35)

Done: AndroidX migration, `compile`->`implementation/api`, namespaces, Flurry tracking removed,
`once` replaced by local class, jcenter removed, NDK STL gnustl->c++_static, armeabi dropped.

Known open issues (expected on first build):
- Java compile errors against android-35 API surface (fix one by one).
- Native: Substrate hook layer only supports ARM32/x86 -> no arm64 yet (see gradle.properties `vaAbis`).
- targetSdk 28 so Android 15 will install it; runtime hooks still written for Android 8.
- Tencent jars in app/libs are 2017 builds (location picker / map); candidates for removal.
Build: `gradle.bat --no-daemon assembleDebug` (needs NDK 26.1.10909125: sdkmanager "ndk;26.1.10909125")

## Phase 2 (Android 9-15 runtime fixes, UNTESTED - no SDK build was possible)
- App: HiddenApiBypass exemptions before VirtualCore.startup (all processes).
- HCallbackStub: LAUNCH_ACTIVITY is gone on Android 9+; handle EXECUTE_TRANSACTION / LaunchActivityItem instead.
- InvocationStubManager: every hook is created/injected inside try/catch (log tag "VA++") so one broken hook can't kill the process.
- New ActivityTaskManagerStub (Android 10+): startActivity & co. are served by IActivityTaskManager.
- ActivityStack / ActivityManagerCompat: start/finish stub activity through IActivityTaskManager on Android 10+.
- StartActivity proxy: callingPackage is args[1]; Android 11+ callingFeatureId handled.
- Home: after adding an app, fall back to reloading the list on any failure; drag crash noise removed.
